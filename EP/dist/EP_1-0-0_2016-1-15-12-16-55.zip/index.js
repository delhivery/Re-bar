require('buffer');
var async = require('async');
var sleep = require('sleep');
require('events').EventEmitter.prototype._maxListeners = 100;
var Client = require('./client').Client;
var Parser = require('./parser').Parser;
var ScanReader = require('./reader').ScanReader;
var Utils = require('./utils');
var util = require('util')
var pushToKinesis = require('./kinesis').pushToKinesis;
var config = require('./config.json')

MODES = ['RCSP', 'STSP']
VERTEX_NAME_CODE_MAPPING = require('./mapper.json')


var CLIENT = new Client(config.HOST, config.PORT)
var RECORDS_TO_PROCESS = []
var LOCKED = []


function lockwbn (record) {
    var wbn = record['wbn']
    // console.log('Locking wbn '+wbn)
    if (LOCKED.indexOf(wbn) < 0){
        LOCKED.push(wbn)
    }
}


function unlockwbn (record) {
    var wbn = record['wbn']
    // console.log('UnLocking wbn '+wbn)
    if (LOCKED.indexOf(wbn) >= 0){
        LOCKED.pop(wbn)
    }
    if (RECORDS_TO_PROCESS.indexOf(record) >= 0){
        RECORDS_TO_PROCESS.pop(record)
    }
}

function isLocked (record) {
    var wbn = record['wbn']
    return LOCKED.indexOf(wbn) >= 0
}


function processScan (record, callback) {
    var scanner = new ScanReader(CLIENT, config.HOST, config.PORT, true)
    result = scanner.read(record)
    result.then(function(res){
        unlockwbn(record)
        callback()
    })
}
// handles data recieved from kinesis
function handlePayload(records, callback) {
    // records.forEach( function(encoded_record, index) {
    //     var record = Utils.decode_record(encoded_record)
    //     RECORDS_TO_PROCESS.push(record)
    // });

    // async.eachSeries(RECORDS_TO_PROCESS, function(record, callbackFromForEach){
    //     var wbn = record['wbn']
    //     console.log('wbn '+ wbn)
    //     console.log('')
    //     // sleep.sleep(3)
    //     if (isLocked(record)){
    //         callbackFromForEach()
    //     } else {
    //         lockwbn(record)
    //         processScan(record, callbackFromForEach)
    //     }
    // }, function(){
    //     callback('Done');
    // })



    async.eachSeries(records, function(record, callbackFromForEach){
        var record = Utils.decode_record(record)
        var wbn = record['wbn']
        if (LOCKED.indexOf(wbn) >= 0){
            callbackFromForEach()
        } else {
            // // ignore if pacakage if of return type
            // if (Utils.isReturnPackage(record)){
            //     callbackFromForEach()
            // } else {
            var scanner = new ScanReader(CLIENT, config.HOST, config.PORT, true)
            result = scanner.read(record)
            result.then(function(res){
                callbackFromForEach()
                // kinesisPush = pushToKinesis(scanner.__parser.value())
                // kinesisPush.then(function (res) {
                //     // console.log('Pushed to kinesis: '+ res)
                //     callbackFromForEach()
                // })
            })
            // }
        }
    }, function(){
        callback('Done');
    })
};


// main handler for this lambda function
exports.handler = function(event, context) {
    handlePayload(event.Records, function(response){
        if (response === 'Success'){
            context.succeed
        } else {
            context.fail
        }
    })
};

