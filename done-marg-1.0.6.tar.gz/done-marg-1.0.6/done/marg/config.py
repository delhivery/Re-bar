'''
This module stores the various constant configurations
used by done.marg
'''
DAY_IN_SECONDS = 24 * 3600

TIME_FORMAT = '%H:%M:%S'
