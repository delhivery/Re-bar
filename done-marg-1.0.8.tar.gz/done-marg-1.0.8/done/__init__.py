'''
This module only exists to indicate the namespace done
for the marg sub-module
'''

__import__('pkg_resources').declare_namespace(__name__)
